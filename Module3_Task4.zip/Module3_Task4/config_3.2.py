# Загружать файлы с доступами, токенами, паролями в гит - путь к провалу!
# Следите за безопасностью!
TOKEN = "6692081952:AAFi4pdTMmXpq-G1pCCdUwbu5Rn8il-Eeh4"

GPT_LOCAL_URL = 'http://localhost:1234/v1/chat/completions'
GPT_WEB_URL = 'обратиться к наставнику'

HEADERS = {"Content-Type": "application/json"}

MAX_TOKENS = 150